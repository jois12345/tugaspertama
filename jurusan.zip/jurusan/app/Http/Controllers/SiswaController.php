<?php

namespace App\Http\Controllers;

use App\Siswa;
use Illuminate\Http\Request;
use App\Jurusan;

class SiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $siswas = Siswa::all();
        return view('Siswa.index', [ 
            'siswas' => $siswas
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $jurusans = Jurusan::all();
        return view('siswa.create', [
            'jurusans' => $jurusans
        ]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = validator($request->all(), [
            'id_jurusan' => 'required|integer',
            'nama' => 'required|string|max:255',
            'deskripsi' => 'required|string',
        ])->validate();

        $siswa = new Siswa($validateData);
        $siswa->save();

        return redirect(route('daftarSiswa'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function show(Siswa $siswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function edit(Siswa $siswa)
    {
        $jurusans = Jurusan::all();
        return view('siswa.edit', [
            'siswa' => $siswa,
            'jurusans' => $jurusans
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Siswa $siswa)
    {
        $validatedData = validator($request->all(), [
            'id_jurusan' => 'required|integer',
            'nama' => 'required|string|max:255',
            'deskripsi' => 'required|string',
        ])->validate();

        $siswa->id_jurusan = $validatedData['id_jurusan'];
        $siswa->nama = $validatedData['nama'];
        $siswa->deskripsi = $validatedData['deskripsi'];
        $siswa->save();

        return redirect(route('daftarSiswa'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Siswa  $siswa
     * @return \Illuminate\Http\Response
     */
    public function destroy(Siswa $siswa)
    {
        $siswa->delete();
        return redirect(route('daftarSiswa'));
    }
}
