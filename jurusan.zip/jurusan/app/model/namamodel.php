<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Artikel extends Model
  {
      protected $table = 'artikel';
      protected $primaryKey = 'id_artikel';

      // mass assignment
      protected $fillable = [
          'url_gambar',
          'judul',
          'teks'
      ];

      // default attributes
      protected $attributes = [
        'url_gambar' => '',
        'judul' => '',
        'teks' => ''
    ];
  }