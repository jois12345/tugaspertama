<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">data siswa</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
					<li class="breadcrumb-item active">SISWA</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<?php $__env->startSection('addCss'); ?>
<link rel="stylesheet" href="<?php echo e(asset ('css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
$(function(){
$("#data-table").DataTable()})
</script>

<script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

<script>
confirmDelete = function(button){
var url = $(button).data('url');
swal({
'title': 'Konfirmasi Hapus',
'text':'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
'dangerMode': true,
'buttons': true
}).then(function(value) {
if (value){
window.location = url;
}
})
}
</script>
<?php $__env->stopSection(); ?>


<div class="card">
    <div class="card-header text-right">
        <a href="<?php echo e(route('createSiswa')); ?>" class="btn btn-primary" role="button">Tambah mata pelajaran</a>
</div>
        <div class="card-body p-0">
            <table class ="table table-hover mb-0" id="data-table">
                <thead>
                <tr>
                        <th>No.</th>
                        <th>Nama siswa.</th>
                        <th>Nama Jurusan</th>
                        <th> Deskripsi </th>
                        <th>Aksi</th>
</tr>
                </thread>
                <tbody>

                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index + 1); ?> </td>
                            <td> <?php echo e($siswa->nama); ?> </td>
                            <td> <?php echo e($siswa->jurusan ? $siswa->jurusan->nama : '-'); ?> </td>
                            <td> <?php echo e($siswa->deskripsi); ?></td>
                            <td>
                                <a href="<?php echo e(route('editSiswa', ['id' => $siswa->id])); ?>" class ="btn btn-warning btn-sm" role ="button">Edit</a>
                                <a onclick="confirmDelete" data-url= a href="<?php echo e(route('deleteSiswa',['id' => $siswa->id])); ?>" class ="btn btn-danger btn-sm" role ="button">Hapus</a>
                                
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jurusan\resources\views/Siswa/index.blade.php ENDPATH**/ ?>