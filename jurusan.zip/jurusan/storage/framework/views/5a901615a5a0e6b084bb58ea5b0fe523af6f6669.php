<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Jurusan gan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
					<li class="breadcrumb-item active">Jurusan gan</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<div class="card">
    <div class="card-header text-right">
        <a href="<?php echo e(route('createJurusan')); ?>" class="btn btn-primary" role="button">Tambah Jurusan</a>
    </div>
    <div class="card-body p-0">
     ...
</div>
</div>

<!-- Main content -->
<div class="content">
	<div class="container-fluid">


    <div class ="card">
        <div class="card-body p-0">
            <table class ="table table=hover mb-0">
                <thead>
                <tr>
                        <th>No.</th>
                        <th>Nama Jurusan</th>
                        <th> Deskripsi </th>
                        <th>Aksi</th>
                </tr>
                </thread>
                <tbody>
                    <tr>

                        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index + 1); ?> </td>
                            <td> <?php echo e($jurusan->nama); ?> </td>
                            <td> <?php echo e($jurusan->deskripsi); ?></td>

                            <td>
                                <a href="<?php echo e(route('editJurusan', ['id' => $jurusan->id])); ?>" class ="btn btn-warning btn-sm" role ="button">Edit</a>
                                <a href="<?php echo e(route('deleteJurusan', ['id' => $jurusan->id])); ?>" class ="btn btn-danger btn-sm" role ="button">Hapus</a>
                            
                            </td>
                        </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tr>
                </tbody>
            </table>
        </div>
    </div>

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jurusan\resources\views/jurusan/index.blade.php ENDPATH**/ ?>