<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Starter</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
					<li class="breadcrumb-item active">Starter</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
	<div class="container-fluid">

		

    <div class ="card">
        <div class="card-body">
  <form action="<?php echo e(route('updateSiswa', ['id' => $siswa->id])); ?>" method="post">
      <?php echo csrf_field(); ?> 
      

      <div class="form-group">
        <label for="id_jurusan">Nama Jurusan</label> 
        <select class="form-control" name="id_jurusan" id="id_jurusan" required="required">
        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($jurusan->id); ?>"><?php echo e($jurusan->id == $siswa->id_jurusan ? ' ' : ''); ?>><?php echo e($jurusan->nama); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
    </div>

      <div class='form-group'>
          <label for="nama">Nama Siswa</label>
          <input type="text" name="nama" id="nama" class="form-control" required="required" value="<?php echo e($siswa->nama); ?>" placeholder="masukkan namamu">
</div>

      <div class='form-group'>
          <label for="deskripsi">Deskripsi</label>
          <textarea name="deskripsi" id="deskripsi" rows="3" class="form-control" required="required" placeholder="masukkan deskripsi tentengmu"><?php echo e($siswa->deskripsi); ?></textarea>
</div>
          
   <div class="text-right">
        <a href="<?php echo e(route('daftarSiswa')); ?>" class="btn btn-outline-secondary mr-2" role="button">Batal</a>
          <button type="submit" class="btn btn-primary">simpan</button>
      </div>
  </from>
</div>
</div>

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jurusan\resources\views/siswa/edit.blade.php ENDPATH**/ ?>